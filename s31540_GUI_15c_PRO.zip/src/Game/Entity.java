package Game;

public abstract class Entity {
    public int x;
    public int y;

    public Entity(int x, int y) {
    }
}
